import React, {useState} from 'react';

const createUser = () => {
    return(<></>);
}

export default createUser;